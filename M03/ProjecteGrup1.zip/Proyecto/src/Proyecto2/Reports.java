package Proyecto2;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.*;

public class Reports {
	String user;
	Connection con;
	JFrame frame = new JFrame("Reports");
	JTabbedPane pestanas = new JTabbedPane();
	JPanel [] menu_panel = new JPanel [3];
	int num_batallas;
	String[] lista_batallas;
	
	//Caracteristicas army
	JPanel [] paneles_army = new JPanel [70];
	JButton exit_army = new JButton();
	JLabel [] labels_army = new JLabel[40];
	JComboBox opc_battle = new JComboBox();
	
	//Caracteristicas Resource report
	int [] info_rep = new int [12];
	JPanel [] panelesGrandes = new JPanel[6];
	JPanel [] panelesPeques = new JPanel[26];
	JLabel [] labels = new JLabel[14];
	JLabel [] labels_col = new JLabel[4];

	
	//Caracteristicas Battle Development
	String [] battleDevelopment; 
	JPanel centerPanel = new JPanel();
	JPanel bottomPanel = new JPanel();
	JButton prevPage = new JButton();
	JButton nextPage = new JButton();
	JLabel [] label_text = new JLabel [10];
	int linea_actual=0, pagina_actual=1;


	
	Reports(String user, Connection con) throws SQLException{
		this.user = user;
		this.con = con;
		//Num batallas total
		this.num_batallas = getIDBattles(user, con);
		this.battleDevelopment = getBattleDevelopment(user, this.num_batallas,con);
		
		
		//Lista con las batallas {1,2,3,4,5,6} --> num_batallas = 6;
		this.lista_batallas = new String [this.num_batallas];
		for (int i=0; i< lista_batallas.length; i++) {
			lista_batallas[i] = String.valueOf(i+1);
			opc_battle.addItem(lista_batallas[i]);
		}
		
		for (int i=0; i<menu_panel.length; i++) {
			menu_panel[i] = new JPanel();
			menu_panel[i].setBackground(Color.black);
		}	
	//MENU INITAL ARMIES
		menu_panel[0].setLayout(new GridLayout(10,7));
		
		exit_army.setBackground(Color.red);
		exit_army.setForeground(Color.black);
		exit_army.setText("Go Back");
		exit_army.setFocusable(false);
		exit_army.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				try {
					new Menu_inicial(user, con);
				} catch (ResourceException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});		
		for (int i=0; i<paneles_army.length; i++) {
			paneles_army[i] = new JPanel();
			paneles_army[i].setBackground(Color.black);
			menu_panel[0].add(paneles_army[i]);
		}
		paneles_army[69].add(exit_army);
		
		
		//Instancia de etiquetas
		for (int i=0; i<labels_army.length; i++) {
			labels_army[i] = new JLabel();
			labels_army[i].setBackground(Color.black);
			labels_army[i].setForeground(Color.white);
			labels_army[i].setVisible(true);
		}
		
		labels_army[0].setText("Select Battle");
		labels_army[1].setText("Army Planet");
		labels_army[2].setText("Units");
		labels_army[3].setText("Drops");
		labels_army[4].setText("Initial Army Enemy");
		labels_army[5].setText("Units");
		labels_army[6].setText("Drops");
		labels_army[7].setText("Light Hunter");
		labels_army[8].setText("");
		labels_army[9].setText("");
		labels_army[10].setText("Light Junter");
		labels_army[11].setText("");
		labels_army[12].setText("");
		labels_army[13].setText("Heavy Hunter");
		labels_army[14].setText("");
		labels_army[15].setText("");
		labels_army[16].setText("Heavy Hunter");
		labels_army[17].setText("");
		labels_army[18].setText("");
		labels_army[19].setText("Battle Ship");
		labels_army[20].setText("");
		labels_army[21].setText("");
		labels_army[22].setText("Battle Ship");
		labels_army[23].setText("");
		labels_army[24].setText("");
		labels_army[25].setText("Armored Ship");
		labels_army[26].setText("");
		labels_army[27].setText("");
		labels_army[28].setText("Armored Ship");
		labels_army[29].setText("");
		labels_army[30].setText("");
		labels_army[31].setText("Missile Launcher");
		labels_army[32].setText("");
		labels_army[33].setText("");
		labels_army[34].setText("Ion Cannon");
		labels_army[35].setText("");
		labels_army[36].setText("");
		labels_army[37].setText("Plasma Cannon");
		labels_army[38].setText("");
		labels_army[39].setText("");
		
		paneles_army[0].add(labels_army[0]);
		
		paneles_army[1].add(opc_battle);
		
		paneles_army[14].add(labels_army[1]);
		paneles_army[15].add(labels_army[2]);
		paneles_army[16].add(labels_army[3]);
		paneles_army[18].add(labels_army[4]);
		paneles_army[19].add(labels_army[5]);
		paneles_army[20].add(labels_army[6]);
		paneles_army[21].add(labels_army[7]);
		paneles_army[22].add(labels_army[8]);
		paneles_army[23].add(labels_army[9]);
		paneles_army[25].add(labels_army[10]);
		paneles_army[26].add(labels_army[11]);
		paneles_army[27].add(labels_army[12]);
		paneles_army[28].add(labels_army[13]);
		paneles_army[29].add(labels_army[14]);
		paneles_army[30].add(labels_army[15]);
		paneles_army[32].add(labels_army[16]);
		paneles_army[33].add(labels_army[17]);
		paneles_army[34].add(labels_army[18]);
		paneles_army[35].add(labels_army[19]);
		paneles_army[36].add(labels_army[20]);
		paneles_army[37].add(labels_army[21]);
		paneles_army[39].add(labels_army[22]);
		paneles_army[40].add(labels_army[23]);
		paneles_army[41].add(labels_army[24]);
		paneles_army[42].add(labels_army[25]);
		paneles_army[43].add(labels_army[26]);
		paneles_army[44].add(labels_army[27]);
		paneles_army[46].add(labels_army[28]);
		paneles_army[47].add(labels_army[29]);
		paneles_army[48].add(labels_army[30]);
		paneles_army[49].add(labels_army[31]);
		paneles_army[50].add(labels_army[32]);
		paneles_army[51].add(labels_army[33]);
		paneles_army[56].add(labels_army[34]);
		paneles_army[57].add(labels_army[35]);
		paneles_army[58].add(labels_army[36]);
		paneles_army[63].add(labels_army[37]);
		paneles_army[64].add(labels_army[38]);
		paneles_army[65].add(labels_army[39]);
		
	//MENU RESOURCE REPORT
		menu_panel[1].setLayout(new GridLayout(3,2));
		
		
		info_rep = getBattleInfo(user, this.num_batallas,con);
		for (int i=0; i<panelesGrandes.length; i++) {
			panelesGrandes[i] = new JPanel();
			panelesGrandes[i].setBackground(Color.black);
			panelesGrandes[i].add(menu_panel[1]);
		}
		
		panelesGrandes[0].setLayout(new GridLayout(4,1));
		panelesGrandes[1].setLayout(new GridLayout(3,1));
		panelesGrandes[2].setLayout(new GridLayout(4,1));
		
		panelesGrandes[3].setLayout(new GridLayout(5,1));
		panelesGrandes[4].setLayout(new GridLayout(5,1));
		panelesGrandes[5].setLayout(new GridLayout(5,1));


		
		for (int i=0; i<panelesPeques.length; i++) {
			panelesPeques[i] = new JPanel();
			panelesPeques[i].setBackground(Color.black);
		}
		
		panelesGrandes[0].add(panelesPeques[0]);
		panelesGrandes[0].add(panelesPeques[1]);
		panelesGrandes[0].add(panelesPeques[2]);
		panelesGrandes[0].add(panelesPeques[3]);
		
		panelesGrandes[1].add(panelesPeques[4]);
		panelesGrandes[1].add(panelesPeques[5]);
		panelesGrandes[1].add(panelesPeques[6]);

		panelesGrandes[2].add(panelesPeques[7]);
		panelesGrandes[2].add(panelesPeques[8]);
		panelesGrandes[2].add(panelesPeques[9]);
		panelesGrandes[2].add(panelesPeques[10]);
		
		panelesGrandes[3].add(panelesPeques[11]);
		panelesGrandes[3].add(panelesPeques[12]);
		panelesGrandes[3].add(panelesPeques[13]);
		panelesGrandes[3].add(panelesPeques[14]);
		panelesGrandes[3].add(panelesPeques[15]);
		
		panelesGrandes[4].add(panelesPeques[16]);
		panelesGrandes[4].add(panelesPeques[17]);
		panelesGrandes[4].add(panelesPeques[18]);
		panelesGrandes[4].add(panelesPeques[19]);
		panelesGrandes[4].add(panelesPeques[20]);
		
		panelesGrandes[5].add(panelesPeques[21]);
		panelesGrandes[5].add(panelesPeques[22]);
		panelesGrandes[5].add(panelesPeques[23]);
		panelesGrandes[5].add(panelesPeques[24]);
		panelesGrandes[5].add(panelesPeques[25]);

		
		for (int i=0; i<labels.length; i++) {
			labels[i] = new JLabel();
			labels[i].setBackground(Color.black);
			labels[i].setForeground(Color.white);
			labels[i].setVisible(true);
		}
		
		//Planet Wins (sale texto en verde)
		if (info_rep[8]<info_rep[11]) {
			for (int i=0; i<labels_col.length; i++) {
				labels_col[i] = new JLabel();
				labels_col[i].setBackground(Color.black);
				labels_col[i].setForeground(Color.green);
				labels_col[i].setVisible(true);
			}
			labels_col[0].setText("PLANET WINS");
		}
		//Enemy Wins (sale texto en rojo)
		else {
			for (int i=0; i<labels_col.length; i++) {
				labels_col[i] = new JLabel();
				labels_col[i].setBackground(Color.black);
				labels_col[i].setForeground(Color.red);
				labels_col[i].setVisible(true);
			}
			//Label que esta en el panel Grande 2
			labels_col[0].setText("ENEMY WINS");
		}
		
		//labels de colores que estan en el panel Grande 5
		labels_col[1].setText("Waste generated:");
		labels_col[2].setText("Metal:         "+info_rep[4]);
		labels_col[3].setText("Deuterium:     "+info_rep[5]);
		
		panelesPeques[4].add(labels_col[0]);
		panelesPeques[17].add(labels_col[1]);
		panelesPeques[18].add(labels_col[2]);
		panelesPeques[19].add(labels_col[3]);

		
		labels[0].setText("Cost Planet Army");
		labels[1].setText("Metal:         "+info_rep[0]);
		labels[2].setText("Deuterium:     "+info_rep[1]);
		
		labels[3].setText("Cost Enemy Army");
		labels[4].setText("Metal:         "+info_rep[2]);
		labels[5].setText("Deuterium:     "+info_rep[3]);
		
		labels[6].setText("Looses Planet Army");
		labels[7].setText("Metal:         "+info_rep[6]);
		labels[8].setText("Deuterium:     "+info_rep[7]);
		labels[9].setText("Weight:        "+info_rep[8]);
		
		labels[10].setText("Looses Enemy Army");
		labels[11].setText("Metal:        "+info_rep[9]);
		labels[12].setText("Deuterium:    "+info_rep[10]);
		labels[13].setText("Weight:       "+info_rep[11]);		
		
		
		//Primer panel Grande
		panelesPeques[1].add(labels[0]);
		panelesPeques[2].add(labels[1]);
		panelesPeques[3].add(labels[2]);
		
		//Tercer panel Grande
		panelesPeques[8].add(labels[3]);
		panelesPeques[9].add(labels[4]);
		panelesPeques[10].add(labels[5]);
		
		//Cuarto panel Grande
		panelesPeques[12].add(labels[6]);
		panelesPeques[13].add(labels[7]);
		panelesPeques[14].add(labels[8]);
		panelesPeques[15].add(labels[9]);

		//Sexto panel Grande
		panelesPeques[22].add(labels[10]);
		panelesPeques[23].add(labels[11]);
		panelesPeques[24].add(labels[12]);
		panelesPeques[25].add(labels[13]);
		
	//BATTLE DEVELOPMENT
		menu_panel[2].setLayout(new BorderLayout());
		menu_panel[2].setBackground(new Color(37,40,80));
		menu_panel[2].add(centerPanel,BorderLayout.CENTER);
		menu_panel[2].add(bottomPanel,BorderLayout.SOUTH);
		
		centerPanel.setLayout(new GridLayout(10,1));
		centerPanel.setBackground(Color.black);
		
		bottomPanel.setLayout(new GridLayout(2,1));
		bottomPanel.setBackground(new Color(37,40,80));
		
		for (int i=0; i<label_text.length; i++) {
			label_text[i] = new JLabel();
			label_text[i].setBackground(Color.black);
			label_text[i].setForeground(Color.white);
			label_text[i].setVisible(true);
			centerPanel.add(label_text[i]);	
		}
		
		
		nextPage.setBackground(new Color(100,107,99));
		nextPage.setText("Next page");
		nextPage.setFocusable(false);
		nextPage.setForeground(Color.white);
		
		prevPage.setBackground(new Color(100,107,99));
		prevPage.setText("Previous page");
		prevPage.setFocusable(false);
		prevPage.setForeground(Color.white);
		
		//caso que battle development tiene menos de 10 lineas
		if (battleDevelopment.length <= 10) {
			for (int i=0; i<battleDevelopment.length; i++) {
				label_text[i].setText(battleDevelopment[i]);
			}
			
			nextPage.setEnabled(false);
			prevPage.setEnabled(false);
		}
		else {
			nextPage.setEnabled(true);
			prevPage.setEnabled(true);
			for (int i=0; i<label_text.length; i++) {
				label_text[i].setText(battleDevelopment[i]);
				linea_actual += 1;
			}
		}
		
		nextPage.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				//Caso que haya mas de 10 lineas restantes de texto (FUNCIONA MIL POR MIL)
				if ((linea_actual+10) <= battleDevelopment.length) {
					for (int i=linea_actual; i<(label_text.length+linea_actual) ; i++) {
						label_text[i-linea_actual].setText(battleDevelopment[linea_actual]);				
					}
					linea_actual = linea_actual + 10;
				}
				
				//caso que hayan 0 lineas restantes por leer, es decir linea_actual == battleDevelopment.length; (FUNCIONA MIL POR MIL)
				else if (linea_actual == battleDevelopment.length){
					linea_actual = 0;
					for (int i=0; i<label_text.length; i++) {
						label_text[i].setText(battleDevelopment[i]);
						linea_actual += 1;
					}
				}
				
				//caso que hayan menos de 10 lineas por leer
				else {
					//relleno las lineas que falten hasta llegar al tama�o de la lista
					for (int i = linea_actual; i < battleDevelopment.length; i++ ) {
						label_text[i-linea_actual].setText(battleDevelopment[i]);
					}
					int restants = battleDevelopment.length;
					
					//en caso de la lista no estar acabada en 0, ex: 27 --> las 3 restantes hasta 30 tendr�an el texto anterior, hay que vaciarlas
					if (restants %10 != 0) {
						//while para solo quedarme con la parte entera
						while (restants > 10) {
							restants = restants-10;
						}
						//for que va desde la etiqueta a la que se ha quedado a la �ltima para vaciarlas del texto que tuvieran
						for (int i = restants; i<label_text.length; i++) {
							label_text[i].setText("");
						}
						
					}
					linea_actual = battleDevelopment.length;
				}		
			}		
		});
		
		prevPage.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//caso que est� en el principio del texto
				if (linea_actual == 10) {
					if (battleDevelopment.length % 10 == 0) {
						for (int i = (battleDevelopment.length-10); i<battleDevelopment.length ; i++) {
							label_text[i- (battleDevelopment.length-10) ].setText(battleDevelopment[i]);
						}
						linea_actual = battleDevelopment.length;
					}
					
					else {
						int num_unitat = battleDevelopment.length;
						//para quedarnos con la unidad, por ej. del 27 el 7.
						while (num_unitat > 10) {
							num_unitat = num_unitat - 10;
						}
						//rellena por ej. del 20 (27-7) hasta el 27;
						for (int i = (battleDevelopment.length-num_unitat); i<battleDevelopment.length ; i++) {
							label_text[i- (battleDevelopment.length-num_unitat) ].setText(battleDevelopment[i]);
						}
						//rellenar los 3 restantes con strings vacios, ej 7,8,9
						for (int i = num_unitat; i < label_text.length ; i++) {
							label_text[i].setText("");
						}
						linea_actual = battleDevelopment.length;
					}
				}
				//caso que se encuentre en la ultima pagina
				else if (linea_actual == battleDevelopment.length){
					int num_unitat = battleDevelopment.length;
					//para quedarnos con la unidad, por ej. del 27 el 7.
					while (num_unitat > 10) {
						num_unitat = num_unitat - 10;
					}
					//pongo que la linea actual sea %10 ==0, ej: estaba en la 27, entonces le resto los 7 para estar en la 20 y de ah� 10 para mostrar de la 10-20
					linea_actual = battleDevelopment.length - num_unitat;
					for (int i= (linea_actual-10); i < linea_actual ; i++) {
						label_text[i - (linea_actual-10)].setText(battleDevelopment[i]);
					}
				}
				//caso general, que pase de linea %10==0 a otra que %10 ==0
				else {
					for (int i= (linea_actual-10); i < linea_actual ; i++) {
						label_text[i - (linea_actual-10)].setText(battleDevelopment[i]);
					}
					linea_actual = linea_actual - 10;
				}
			}
		});
		
		//FINAL
		opc_battle.setPreferredSize(new Dimension(45,20));
		pestanas.addTab("Initial Armies", menu_panel[0]);
		pestanas.addTab("Resources report", menu_panel[1]);
		pestanas.addTab("Battle Development", menu_panel[2]);
		frame.add(pestanas);
		Image img_icon = new ImageIcon("iconoTotal.png").getImage();
		frame.setIconImage(img_icon);
		frame.setSize(1120,682);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setResizable(false);
	}
	
	//Funcion que devuelve el num de id_battles que tiene es user
	public int getIDBattles(String user, Connection con) throws SQLException {
		String query = "select count(id_battle) from battle where id_user = "
				+ "(select id_user from user_pw where username = '"+user+"') order by id_battle desc";
		Statement stmn = con.createStatement();
		ResultSet rs = stmn.executeQuery(query);
		rs.next();
		return rs.getInt(1);
	}
	
	public String[] getBattleDevelopment(String user, int pelea,Connection con) throws SQLException {
		String batt_dep="";  
		String id = "select id_user from user_pw where username = '" + user +"'";
		PreparedStatement pstm = con.prepareStatement(id);
		ResultSet rs1 = pstm.executeQuery();
		rs1.next();
		int id_u = rs1.getInt(1);
		
		CallableStatement cst = con.prepareCall("{CALL search_id_battle (?,?,?)}");
        cst.setString(1, user);
        cst.setInt(2, pelea);
        cst.registerOutParameter(3, java.sql.Types.INTEGER);
        cst.execute();
        Integer id_bat = cst.getInt(3);
		
        String bat_rep = "select battle_development1, battle_development2, battle_development3, battle_development4 from battle where id_battle = " + id_bat;
        
        Statement stmn = con.createStatement();
		ResultSet rs = stmn.executeQuery(bat_rep);
		rs.next();
		batt_dep += rs.getString(1) + rs.getString(2) + rs.getString(3) +rs.getString(4);
		
		
		//Divido el String por sus saltos de lÃ­nea y los meto en una lista
		String [] output = batt_dep.split("\\n");
		
		
		return output;
	}
	
	public int [] getBattleInfo(String user, int pelea, Connection con ) throws SQLException {
		int [] info = new int [12];  //  [cap_m,cap_d,cae_m,cae_d,waste_m,waste_d,lap_m,lap_d,lap_w,lae_m,lae_d,lae_w]

		String id = "select id_user from user_pw where username = '" + user+"'";
		PreparedStatement pstm = con.prepareStatement(id);
		ResultSet rs1 = pstm.executeQuery();
		rs1.next();
		int id_u = rs1.getInt(1);
		CallableStatement cst = con.prepareCall("{CALL search_id_battle (?,?,?)}");
        cst.setString(1, user);
        cst.setInt(2, pelea);
        cst.registerOutParameter(3, java.sql.Types.INTEGER);
        cst.execute();
        Integer id_bat = cst.getInt(3);
		
		CallableStatement cst2 = con.prepareCall("{CALL get_battle (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
		cst2.setString(1, user);
		cst2.registerOutParameter(2, java.sql.Types.INTEGER);
		cst2.registerOutParameter(3, java.sql.Types.INTEGER);
		cst2.registerOutParameter(4, java.sql.Types.INTEGER);
		cst2.registerOutParameter(5, java.sql.Types.INTEGER);
		cst2.registerOutParameter(6, java.sql.Types.INTEGER);
		cst2.registerOutParameter(7, java.sql.Types.INTEGER);
		cst2.registerOutParameter(8, java.sql.Types.INTEGER);
		cst2.registerOutParameter(9, java.sql.Types.INTEGER);
		cst2.registerOutParameter(10, java.sql.Types.INTEGER);
		cst2.registerOutParameter(11, java.sql.Types.INTEGER);
		cst2.registerOutParameter(12, java.sql.Types.INTEGER);
		cst2.registerOutParameter(13, java.sql.Types.INTEGER);
		cst2.registerOutParameter(14, java.sql.Types.INTEGER);
		cst2.registerOutParameter(15, java.sql.Types.VARCHAR);
		cst2.registerOutParameter(16, java.sql.Types.VARCHAR);
		cst2.registerOutParameter(17, java.sql.Types.VARCHAR);
		cst2.registerOutParameter(18, java.sql.Types.VARCHAR);
		
		cst2.execute();
		info[0] = cst2.getInt(2);
		info[1] = cst2.getInt(3);
		info[2] = cst2.getInt(4);
		info[3] = cst2.getInt(5);
		info[4] = cst2.getInt(6);
		info[5] = cst2.getInt(7);
		info[6] = cst2.getInt(8);
		info[7] = cst2.getInt(9);
		info[8] = cst2.getInt(10);
		info[9] = cst2.getInt(11);
		info[10] = cst2.getInt(12);
		info[11] = cst2.getInt(13);
		
		
		return info;
	}

	
	
}
