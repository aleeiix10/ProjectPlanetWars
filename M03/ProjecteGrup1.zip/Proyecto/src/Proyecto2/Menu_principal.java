package Proyecto2;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Menu_principal extends JFrame{
	private JFrame frame = new JFrame("Planet Wars");
	private JPanel panel[] = new JPanel[30];
	private JLabel etiqueta[]= new JLabel[30];
	private JButton boton[]=new JButton[3];
	private Planet planeta;
	private Connection con;
	private int opc;
	Menu_principal () throws SQLException{
		
		Conexion db=new Conexion("jdbc:oracle:thin:@localhost:1521:xe","HR","HR");	
		this.con = db.getCn();
		
		CallableStatement cst;
		cst = con.prepareCall("{CALL initialize (?)}");
		cst.setInt(1, 0);
		cst.execute();
		
		for (int i=0;i<etiqueta.length;i++) {
		etiqueta[i] = new JLabel();
		etiqueta[i].setForeground(Color.white);
		
		}
		
		for (int i=0;i<panel.length;i++) {
			panel[i] =  new JPanel();
			panel[i].setBackground(Color.black);
		}
		for (int i=0;i<boton.length;i++) {
			boton[i]= new JButton();
			boton[i].setForeground(Color.black);
			boton[i].setBackground(Color.white);
			boton[i].setFocusable(false);
		}
		etiqueta[0].setIcon(new javax.swing.ImageIcon("gif.gif"));
		etiqueta[14].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[15].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[16].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[17].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[18].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[19].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[0].setLayout(new GridLayout(3,3));
		panel[0].add(panel[1]);
		panel[0].add(panel[2]);
		panel[2].add(etiqueta[0]);
		panel[0].add(panel[3]);
		panel[0].add(panel[4]);
		panel[1].add(etiqueta[14]);
		panel[3].add(etiqueta[15]);
		panel[4].add(etiqueta[16]);
		panel[6].add(etiqueta[17]);
		panel[7].add(etiqueta[18]);
		panel[8].add(etiqueta[19]);
		etiqueta[1].setText("fffwfwfwfwfwfwf");
		etiqueta[2].setText("fwfwwfwfwfwfwfw");
		etiqueta[3].setText("cqcwwvwvwvwvwvw");
		etiqueta[1].setForeground(Color.black);
		etiqueta[2].setForeground(Color.black);
		etiqueta[3].setForeground(Color.black);		
		boton[0].setText("LOGIN");
		boton[1].setText("REGISTER");
		boton[2].setText("EXIT");
		panel[5].setLayout(new GridLayout(1,3));
		etiqueta[20].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[21].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[10].add(etiqueta[20]);
		panel[12].add(etiqueta[21]);
		panel[5].add(panel[10]);
		panel[5].add(panel[11]);
		panel[5].add(panel[12]);
		panel[11].add(etiqueta[1]);
		panel[11].add(etiqueta[2]);
		panel[11].add(etiqueta[3]);
		panel[11].add(boton[0]); 
		panel[11].add(etiqueta[12]);
		panel[11].add(boton[1]);
		panel[11].add(etiqueta[13]);
		panel[11].add(boton[2]);
		panel[9].setLayout(new GridLayout(1,3));
		panel[9].add(panel[13]);
		panel[9].add(panel[14]);
		panel[9].add(panel[15]);
		etiqueta[22].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[23].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[13].add(etiqueta[22]);
		panel[15].add(etiqueta[23]);
		etiqueta[4].setFont(new Font("Serif", Font.PLAIN, 14));
		etiqueta[5].setFont(new Font("Serif", Font.PLAIN, 14));
		etiqueta[6].setFont(new Font("Serif", Font.PLAIN, 14));
		etiqueta[7].setFont(new Font("Serif", Font.PLAIN, 14));
		etiqueta[8].setText("Vwsvvwvwvwvv");
		etiqueta[9].setText("Vwsvvwvwvwvv");
		etiqueta[10].setText("Vwsvvwvwvwvv");
		etiqueta[11].setText("Vwsvvwvwvwvv");
		etiqueta[12].setText("Vwsvvwvwvwvv");
		etiqueta[13].setText("Vwsvvwvwvwvv");
		etiqueta[8].setForeground(Color.black);	
		etiqueta[9].setForeground(Color.black);	
		etiqueta[8].setForeground(Color.black);	
		etiqueta[9].setForeground(Color.black);	
		etiqueta[10].setForeground(Color.black);	
		etiqueta[11].setForeground(Color.black);
		etiqueta[12].setForeground(Color.black);	
		etiqueta[13].setForeground(Color.black);
		etiqueta[4].setText("Eric Escrich");
		etiqueta[5].setText("Borja Montoro");
		etiqueta[6].setText("Brahian Monsalve");
		etiqueta[7].setText("Aleix Sastre");
		panel[14].add(etiqueta[8]);		
		panel[14].add(etiqueta[9]);
		panel[14].add(etiqueta[10]);
		panel[14].add(etiqueta[11]);
		panel[14].add(etiqueta[4]);
		panel[14].add(etiqueta[5]);
		panel[14].add(etiqueta[6]);
		panel[14].add(etiqueta[7]);
		
		panel[0].add(panel[5]);
		panel[0].add(panel[6]);
		panel[0].add(panel[7]);
		panel[0].add(panel[8]);
		panel[0].add(panel[9]);
		
		Image img_icon = new ImageIcon("iconoTotal.png").getImage();
		frame.setIconImage(img_icon);
		frame.add(panel[0]);
		frame.setResizable(false);
		frame.setSize(1120,682);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		boton[0].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new Menu_login();
				
			}
		});
		boton[1].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new Menu_register();
				
			}
		});
		boton[2].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();

				
			}
		});
		
		
	}
	public int getOption() {
		return this.opc;
	}
	
	public void setOption(int opc) {
		this.opc = opc;
	}
}