package Proyecto2;

public class LigthHunter extends Ship implements MilitaryUnit{
	
	private int armadura_plus = Variables.PLUS_ARMOR_LIGTHHUNTER_BY_TECHNOLOGY;
	private int dano_plus = Variables.PLUS_ATTACK_LIGTHHUNTER_BY_TECHNOLOGY;
	private int lvl_Def;
	private int lvlAtt;
	
	LigthHunter(int armor,int baseDamage, int lvlAtt, int lvl_Def){
		super(armor, baseDamage);
		this.lvlAtt = lvlAtt;
		this.lvl_Def = lvl_Def;
	}
	
	LigthHunter() {
		super(Variables.ARMOR_LIGTHHUNTER, Variables.BASE_DAMAGE_LIGTHHUNTER);
		this.lvlAtt = 1;
		this.lvl_Def = 1;
	};
	
	
	@Override
	public int attack() {
		return getBaseDamage();
	}

	@Override
	public void takeDamage(int receivedDamage) {
		setArmor(getActualArmor()-receivedDamage);
	}

	@Override
	public int getActualArmor() {
		return getArmor();
	}

	@Override
	public int getMetalCost() {
		return Variables.METAL_COST_LIGTHHUNTER;
	}

	@Override
	public int getDeuteriumCost() {
		return Variables.DEUTERIUM_COST_LIGTHHUNTER;
	}

	@Override
	public int getChanceGeneratinWaste() {
		int porcentaje=Variables.CHANCE_GENERATNG_WASTE_LIGTHHUNTER;
		int num_random;
		
		num_random = (int)(Math.random()*101);
		
		if (num_random<=porcentaje) {
			return 1;
		}
		
		return 0;
	}

	@Override
	public int getChanceAttackAgain() {
		int porcentaje=Variables.CHANCE_ATTACK_AGAIN_LIGTHHUNTER;
		int num_random;
		
		num_random = (int)(Math.random()*101);
		
		if (num_random<=porcentaje) {
			return 1;
		}
		
		return 0;
	}

	@Override
	public void resetArmor() {
		setArmor(getInitialArmor());
	}

	@Override
	public String toString() {
		return "Ligth Hunter";
	}

	@Override
	public int getLvlAttTech() {
		return this.lvlAtt;
	}

	@Override
	public int getLvlDefTech() {
		return this.lvl_Def;
	}

}
