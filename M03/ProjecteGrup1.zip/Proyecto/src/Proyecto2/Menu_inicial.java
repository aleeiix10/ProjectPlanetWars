package Proyecto2;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Menu_inicial{
	String user;
	JFrame frame = new JFrame("INICIAL");
	JPanel panel[] = new JPanel[70];
	JButton botones[]= new JButton[7];
	JLabel etiqueta[]= new JLabel[50];
	private Planet planeta;
	Menu_inicial(String user,Connection con) throws ResourceException, SQLException{		
		this.user = user;
		this.planeta = getPlaneta(user, con);
		
		for (int i=0;i<panel.length;i++) {
			panel[i]= new JPanel();
			panel[i].setBackground(Color.black);
		}
		for (int i=0;i<botones.length;i++) {
			botones[i]= new JButton();
			botones[i].setFocusable(false);
			
			
		}
		for (int i=0;i<etiqueta.length;i++) {
			etiqueta[i]= new JLabel();
			etiqueta[i].setForeground(Color.white);
			
		}
		
		panel[0].setLayout(new GridLayout(3,3));
		//PANEL 1
		etiqueta[0].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[1].add(etiqueta[0]);
		panel[0].add(panel[1]);
		//PANEL 2
		etiqueta[1].setIcon(new javax.swing.ImageIcon("gif.gif"));
		panel[2].add(etiqueta[1]);
		panel[0].add(panel[2]);
		
		//PANEL 3
		panel[3].setLayout(new GridLayout(2,2));
		
		etiqueta[2].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[10].add(etiqueta[2]);
		panel[3].add(panel[10]);
		panel[3].add(panel[11]);
		
		etiqueta[3].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[12].add(etiqueta[3]);
		panel[3].add(panel[12]);
		
		etiqueta[4].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[13].add(etiqueta[4]);
		panel[3].add(panel[13]);
		
		panel[11].setLayout(new GridLayout(2,1));
		panel[11].add(panel[14]);
		panel[11].add(panel[15]);
		panel[0].add(panel[3]);
		//PANEL 4
		panel[4].setLayout(new GridLayout(2,2));
		etiqueta[5].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[16].add(etiqueta[5]);
		panel[4].add(panel[16]);
		panel[4].add(panel[17]);
		
		etiqueta[6].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[18].add(etiqueta[6]);
		panel[4].add(panel[18]);
		
		etiqueta[7].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[19].add(etiqueta[7]);
		panel[4].add(panel[19]);
		
		panel[17].setLayout(new GridLayout(2,1));
		etiqueta[8].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[20].add(etiqueta[8]);
		panel[17].add(panel[20]);
		panel[17].add(panel[21]);
		botones[0].setText("   BUILD  ");
		panel[21].add(botones[0]);
		panel[0].add(panel[4]);
		//PANEL 5
		panel[5].setLayout(new GridLayout(2,3));
		
		etiqueta[9].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[22].add(etiqueta[9]);
		panel[5].add(panel[22]);
		
		panel[23].setLayout(new GridLayout(2,1));
		etiqueta[10].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[24].add(etiqueta[10]);
		panel[23].add(panel[24]);
		botones[1].setText("VIEW STATS");
		panel[25].add(botones[1]);
		panel[23].add(panel[25]);
		panel[5].add(panel[23]);
		
		etiqueta[11].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[26].add(etiqueta[11]);
		panel[5].add(panel[26]);
		
		etiqueta[12].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[27].add(etiqueta[12]);
		panel[5].add(panel[27]);
		
		etiqueta[13].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[28].add(etiqueta[13]);
		panel[5].add(panel[28]);
		
		etiqueta[14].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[29].add(etiqueta[14]);
		panel[5].add(panel[29]);
		
		panel[0].add(panel[5]);
		
		//PANEL 6
		panel[6].setLayout(new GridLayout(2,2));
		panel[6].add(panel[30]);
		panel[30].setLayout(new GridLayout(2,1));
		etiqueta[15].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[31].add(etiqueta[15]);
		panel[30].add(panel[31]);
		botones[2].setText("UPGRADE");
		panel[32].add(botones[2]);
		panel[30].add(panel[32]);
		panel[0].add(panel[6]);
		
		etiqueta[16].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[33].add(etiqueta[16]);
		panel[6].add(panel[33]);
		
		etiqueta[17].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[34].add(etiqueta[17]);
		panel[6].add(panel[34]);
		
		etiqueta[18].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[35].add(etiqueta[18]);
		panel[6].add(panel[35]);
		
		
		//PANEL 7 
		panel[7].setLayout(new GridLayout(2,2));
		etiqueta[19].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[36].add(etiqueta[19]);
		panel[7].add(panel[36]);
		panel[7].add(panel[37]);
		
		etiqueta[20].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[38].add(etiqueta[20]);
		panel[7].add(panel[38]);
		
		etiqueta[21].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[39].add(etiqueta[21]);
		panel[7].add(panel[39]);
		
		panel[37].setLayout(new GridLayout(2,1));
		etiqueta[22].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[40].add(etiqueta[22]);
		panel[37].add(panel[40]);
		panel[37].add(panel[41]);
		botones[3].setText("   THREAD  ");
		panel[41].add(botones[3]);
		panel[0].add(panel[7]);
		
		//PANEL 8
		panel[8].setLayout(new GridLayout(2,3));
		etiqueta[23].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[42].add(etiqueta[23]);
		panel[8].add(panel[42]);
		
		botones[4]=new RoundButton("  DANGER  ");
		botones[4].setBackground(Color.red);
		botones[4].setForeground(Color.white);
		panel[43].add(botones[4]);
		panel[8].add(panel[43]);
		
		etiqueta[24].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[44].add(etiqueta[24]);
		panel[8].add(panel[44]);
		
		etiqueta[25].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[45].add(etiqueta[25]);
		panel[8].add(panel[45]);
		
		panel[46].setLayout(new GridLayout(2,1));
		
		etiqueta[27].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		
		panel[49].add(etiqueta[27]);
		panel[46].add(panel[49]);
		
		botones[6].setText("  EXIT  ");
		panel[48].add(botones[6]);
		panel[46].add(panel[48]);
		
		panel[8].add(panel[46]);
		
		etiqueta[26].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[47].add(etiqueta[26]);
		panel[8].add(panel[47]);
		
		panel[0].add(panel[8]);
		//PANEL 9
		panel[9].setLayout(new GridLayout(2,2));
		panel[9].add(panel[50]);
		panel[50].setLayout(new GridLayout(2,1));
		etiqueta[28].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[51].add(etiqueta[28]);
		panel[50].add(panel[51]);
		botones[5].setText("REPORTS");
		panel[52].add(botones[5]);
		panel[50].add(panel[52]);
		panel[0].add(panel[9]);
		
		etiqueta[29].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[53].add(etiqueta[29]);
		panel[9].add(panel[53]);
		
		etiqueta[30].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[54].add(etiqueta[30]);
		panel[9].add(panel[54]);
		
		etiqueta[31].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[55].add(etiqueta[31]);
		panel[9].add(panel[55]);
		
		panel[0].add(panel[9]);
		
		Image img_icon = new ImageIcon("iconoTotal.png").getImage();
		frame.setIconImage(img_icon);
		frame.add(panel[0]);
		frame.setResizable(false);
		frame.setSize(1120,682);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
		//Boton para build
		botones[0].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new Build(planeta, user);
				
			}
		});
		
		//boton para printar stats del planeta
		botones[1].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				try {
					planeta.printStats(user);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		//BOTON PARA MENU UPGRADE
		botones[2].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new Menu_upgradeTec(planeta, user);
				
			}
		});
		
		botones[3].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		
		botones[4].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				CallableStatement cst;
				try {
					cst = con.prepareCall("{CALL initialize(?)}");
					cst.setInt(1, 1);
					cst.execute();
					frame.dispose();
					new Menu_principal();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
				

			}
		});
		
		//BOTON REPORTS
		botones[5].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					new Reports(user, con);
					System.out.println("a");
				} catch (SQLException e1) {
					System.out.println("b");
					e1.printStackTrace();
				}
				frame.dispose();
			}
		});
		
		//BOTON EXIT
		botones[6].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				try {
					new Menu_principal();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		//timer para aumentar recursos
		Timer time1min = new Timer();
		TimerTask recursos = new TimerTask() {		
			@Override
			public void run() {
				planeta.setMetal(planeta.getMetal() + Variables.PLANET_METAL_GENERATED);
				planeta.setDeuterium(planeta.getDeuterium() + Variables.PLANET_DEUTERIUM_GENERATED);
				try {
					planeta.updatePlanetToBDD();
					planeta.setTroopsToBDD(planeta.getArmy(), con);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		};
		time1min.schedule(recursos, (1000)*60 , (1000)*60);
		
		//timer que avisa cada 3 mins de que te atacan
		Timer time3mins = new Timer();
		TimerTask ataque = new TimerTask() {
			@Override
			public void run() {
				new PopUpPers("Your planet has been attacked", "satelite.png", 70, 50);
				try {
					
					Battle batalla = new Battle(planeta, con);
					Thread thr = new Thread(batalla.getInitialArmies(),planeta);
					
					batalla.LOLPlayers();
					System.out.println(batalla.getDevelopment());
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		time3mins.schedule(ataque, (1000)*180 ,(1000)*240);
	}
	public Planet getPlaneta(String user, Connection con) throws ResourceException, SQLException {
        //user-> nombreplaneta, ataquetech, defensetech, deut, metal, cristal
        CallableStatement cst = con.prepareCall("{CALL get_planet (?,?,?,?,?,?,?)}");
        cst.setString(1, user);
        cst.registerOutParameter(2, java.sql.Types.VARCHAR);
        cst.registerOutParameter(3, java.sql.Types.INTEGER);
        cst.registerOutParameter(4, java.sql.Types.INTEGER);
        cst.registerOutParameter(5, java.sql.Types.INTEGER);
        cst.registerOutParameter(6, java.sql.Types.INTEGER);
        cst.registerOutParameter(7, java.sql.Types.INTEGER);

        cst.execute();

        String nombrePlanet = cst.getString(2);
        Integer attTech = cst.getInt(3);
        Integer defTech = cst.getInt(4);
        Integer deut = cst.getInt(5);
        Integer crist = cst.getInt(6);
        Integer metal = cst.getInt(7);

        Planet planeta = new Planet(nombrePlanet, user, con);
        planeta.setTechonologyAttack(attTech);
        planeta.setTechnologyDefense(defTech);
        planeta.setDeuterium(deut);
        planeta.setMetal(metal);

        return planeta;
    }
	
}