package Proyecto2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Menu_register extends JFrame{
	private JFrame frame = new JFrame("REGISTER");
	private JPasswordField pass= new JPasswordField(15);
	private JPanel panel[] = new JPanel[30];
	private JLabel etiqueta[]= new JLabel[40];
	private JButton boton[]=new JButton[3];
	private JTextField text[]= new JTextField[3];
	private JComboBox dia,mes,ano; 
	
	Menu_register() {
		pass.setBorder(null);
		for (int i=0;i<etiqueta.length;i++) {
		etiqueta[i] = new JLabel();
		etiqueta[i].setForeground(Color.white);
		
		}
		
		for (int i=0;i<panel.length;i++) {
			panel[i] =  new JPanel();
			panel[i].setBackground(Color.black);
		}
		for (int i=0;i<boton.length;i++) {
			boton[i]= new JButton();
			boton[i].setForeground(Color.black);
			boton[i].setBackground(Color.white);
			boton[i].setFocusable(false);
			text[i]= new JTextField(15);
			text[i].setBorder(null);
		
		}
		etiqueta[0].setIcon(new javax.swing.ImageIcon("gif.gif"));
		etiqueta[15].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[16].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[17].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[18].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[19].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[0].setLayout(new GridLayout(3,3));
		panel[0].add(panel[1]);
		panel[0].add(panel[2]);
		panel[2].add(etiqueta[0]);
		panel[0].add(panel[3]);
		panel[0].add(panel[4]);
		panel[1].add(etiqueta[14]);
		panel[3].add(etiqueta[15]);
		panel[4].add(etiqueta[16]);
		panel[6].add(etiqueta[17]);
		panel[7].add(etiqueta[18]);
		panel[8].add(etiqueta[19]);
		etiqueta[1].setText("fffwfwfwfwfwfwf");
		etiqueta[2].setText("fwfwwfwfwfwfwfw");
		etiqueta[3].setText("cqcwwvwvwvwvwvw");
		etiqueta[4].setText("cqcwwvwvwvwvwvw");
		etiqueta[5].setText("cqcwwvwvwvwvwvw");
		etiqueta[12].setText("Vwsvvwvwvwvv");
		etiqueta[13].setText("fvwvwvv");
		etiqueta[14].setText("cqcwwvwvwvwvwvw");
		etiqueta[14].setForeground(Color.black);
		etiqueta[1].setForeground(Color.black);
		etiqueta[2].setForeground(Color.black);
		etiqueta[3].setForeground(Color.black);
		etiqueta[4].setForeground(Color.black);
		etiqueta[5].setForeground(Color.black);
		etiqueta[12].setForeground(Color.black);
		etiqueta[13].setForeground(Color.black);
		boton[0].setText("SUBMIT");
		boton[2].setText("BACK");
		panel[5].setLayout(new GridLayout(2,1));
		etiqueta[21].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[14].setLayout(new GridLayout(1,2));
		etiqueta[29].setText("vccwscwc");
		etiqueta[29].setForeground(Color.black);
		etiqueta[6].setText("USER:    ");
		etiqueta[28].setText("BORN DAY:");
		etiqueta[7].setText("PASSWORD:");
		panel[16].add(etiqueta[14]);
		panel[16].add(etiqueta[12]);
		panel[16].add(etiqueta[6]);
		panel[16].add(etiqueta[13]);
		panel[16].add(etiqueta[7]);
		panel[16].add(etiqueta[29]);
		panel[16].add(etiqueta[28]);
		

		panel[16].setBackground(Color.black);
		panel[17].setBackground(Color.black);
		etiqueta[23].setText("cssswwwvw");
		etiqueta[23].setForeground(Color.black);
		panel[17].add(etiqueta[23]);
		panel[17].add(text[0]);
		//panel[17].add(etiqueta[31]);
		panel[17].add(pass);
		etiqueta[30].setText("wcaw");
		etiqueta[30].setForeground(Color.black);
		etiqueta[31].setText("wcaw");
		etiqueta[31].setForeground(Color.black);
		//panel[17].add(etiqueta[30]);
		String[] anopos= new String[73];
		int anoEm=2022;
		for (int i=0;i<anopos.length;i++) {
			anopos[i]=(String.valueOf(anoEm-i));
		}
		ano = new JComboBox(anopos);
		String[] mespos= {"01","02","03","04","05","06","07","08","09","10","11","12"};
		mes = new JComboBox(mespos);
		String [] diasV= new String[30];
		int diaEm=1;
		for (int i=0;i<diasV.length;i++) {
			diasV[i]=(String.valueOf(diaEm+i));
		}
		dia = new JComboBox(diasV);
		ano.setPreferredSize(new Dimension(65,20));
		mes.setPreferredSize(new Dimension(45,20));
		panel[17].add(ano);
		panel[17].add(mes);
		dia.setPreferredSize(new Dimension(45,20));
		panel[17].add(dia);
		mes.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				String[] diasV = null;
				String AnoStr = (String)ano.getSelectedItem();
				String mesStr = (String)mes.getSelectedItem();
				if (e.getStateChange()==ItemEvent.SELECTED) {
			if ((Integer.parseInt(AnoStr)%4==0 && Integer.parseInt(AnoStr)%100!=0 && mesStr=="02") || (Integer.parseInt(AnoStr)%400==0 && Integer.parseInt(AnoStr)%100==0 && mesStr=="02")) {
				diasV= new String[29];
				dia.removeAllItems();
				int diaEm=01;
				for (int i=0;i<diasV.length;i++) {
					diasV[i]=(String.valueOf(diaEm+i));
					dia.addItem(diasV[i]);
				}
			}
			else if (mesStr=="02") {
				diasV= new String[28];
				dia.removeAllItems();
				int diaEm=01;
				for (int i=0;i<diasV.length;i++) {
					diasV[i]=(String.valueOf(diaEm+i));
					dia.addItem(diasV[i]);
				}
			}
			else if (mesStr=="01" || mesStr=="03" || mesStr=="05" || mesStr=="07" || mesStr=="08" || mesStr=="10" || mesStr=="12") {
				diasV= new String[31];
				dia.removeAllItems();
				int diaEm=01;
				for (int i=0;i<diasV.length;i++) {
					diasV[i]=(String.valueOf(diaEm+i));
					dia.addItem(diasV[i]);
				}
			}
			else if (mesStr=="04" || mesStr=="06" || mesStr=="09" || mesStr=="11") {
				System.out.println("if 4");
				dia.removeAllItems();
				diasV= new String[30];
				int diaEm=01;
				for (int i=0;i<diasV.length;i++) {
					diasV[i]=(String.valueOf(diaEm+i));
					dia.addItem(diasV[i]);
				}
			}
			}
			}
		});

		ano.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				String[] diasV = null;
				String AnoStr = (String)ano.getSelectedItem();
				String mesStr = (String)mes.getSelectedItem();
				if (e.getStateChange()==ItemEvent.SELECTED) {
			if ((Integer.parseInt(AnoStr)%4==0 && Integer.parseInt(AnoStr)%100!=0 && mesStr=="02") || (Integer.parseInt(AnoStr)%400==0 && Integer.parseInt(AnoStr)%100==0 && mesStr=="02")) {
				diasV= new String[29];
				dia.removeAllItems();
				int diaEm=01;
				for (int i=0;i<diasV.length;i++) {
					diasV[i]=(String.valueOf(diaEm+i));
					dia.addItem(diasV[i]);
				}
			}
			else if (mesStr=="02") {
				diasV= new String[28];
				dia.removeAllItems();
				int diaEm=01;
				for (int i=0;i<diasV.length;i++) {
					diasV[i]=(String.valueOf(diaEm+i));
					dia.addItem(diasV[i]);
				}
			}
			else if (mesStr=="01" || mesStr=="03" || mesStr=="05" || mesStr=="07" || mesStr=="08" || mesStr=="10" || mesStr=="12") {
				diasV= new String[31];
				dia.removeAllItems();
				int diaEm=01;
				for (int i=0;i<diasV.length;i++) {
					diasV[i]=(String.valueOf(diaEm+i));
					dia.addItem(diasV[i]);
				}
			}
			else if (mesStr=="04" || mesStr=="06" || mesStr=="09" || mesStr=="11") {
				dia.removeAllItems();
				diasV= new String[30];
				int diaEm=01;
				for (int i=0;i<diasV.length;i++) {
					diasV[i]=(String.valueOf(diaEm+i));
					dia.addItem(diasV[i]);
				}
			}
			}
			}
		});
		//panel[17].add(text[2]);
		panel[14].add(panel[16]);
		panel[14].add(panel[17]);
		panel[15].setLayout(new GridLayout(1,3));
		panel[19].add(etiqueta[27]);
		panel[19].add(boton[0]);
		panel[19].add(boton[2]);
		panel[15].add(panel[18]);
		panel[15].add(panel[19]);
		panel[15].add(panel[20]);
		etiqueta[24].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[25].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[26].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		etiqueta[27].setText("jdjdjdjdjdj");
		etiqueta[27].setForeground(Color.black);
		panel[18].add(etiqueta[24]);
		panel[20].add(etiqueta[25]);
		panel[19].setBackground(Color.black);
		panel[1].add(etiqueta[26]);
		panel[5].add(panel[14]);
		panel[5].add(panel[15]);
		panel[12].add(etiqueta[21]);
		panel[10].add(etiqueta[3]);
		panel[10].add(etiqueta[4]);
		panel[9].add(panel[13]);
		etiqueta[22].setIcon(new javax.swing.ImageIcon("neptuno.gif"));
		panel[13].add(etiqueta[22]);
		
		panel[0].add(panel[5]);
		panel[0].add(panel[6]);
		panel[0].add(panel[7]);
		panel[0].add(panel[8]);
		panel[0].add(panel[9]);
		
		Image img_icon = new ImageIcon("iconoTotal.png").getImage();
		frame.setIconImage(img_icon);
		frame.add(panel[0]);
		frame.setResizable(false);
		frame.setSize(1120,682);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		boton[0].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String user = text[0].getText();
				String password = pass.getText();
				String data = dia.getSelectedItem()+"/"+mes.getSelectedItem()+"/"+ano.getSelectedItem();	
				text[0].setText("");
				pass.setText("");
				ano.setSelectedItem("2022");
				dia.setSelectedItem("1");
				mes.setSelectedItem("01");
				Conexion db=new Conexion("jdbc:oracle:thin:@localhost:1521:xe","HR","HR");	
				CallableStatement cst;
				try {
					if (user.isEmpty() || password.isEmpty()){
						new PopUpPers("One of the two fields is empty","ERROR", "usuario.png",50,50);
					}
					else {
					cst = db.getCn().prepareCall("{CALL registro (?,?,?,?)}");
					cst.setString(1, user);
					cst.setString(2, password);
					cst.setString(3, data);
					cst.registerOutParameter(4, java.sql.Types.INTEGER);
					cst.execute();
					Integer resultado = cst.getInt(4);
					if (resultado == 0) {
							new PopUpPers("The user name already exists","ERROR","usuario.png",50,50);
					}
					else {
							new PopUpPers("User added succesfully","USER","usuario.png",50,50,frame);		
							initPlanetToBDD(user, db.getCn());
							
							new Menu_inicial(user, db.getCn());
						}
					}
				} catch (SQLException | ResourceException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		boton[2].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				try {
					new Menu_principal();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
	}
	
	public void initPlanetToBDD(String user ,Connection con) throws SQLException {
		//nomplanet, nomuser
		CallableStatement cst = con.prepareCall("{CALL set_planet (?,?)}");
		cst.setString(1, user);
		cst.setString(2, user);
        cst.execute();
	}	
	
	
}